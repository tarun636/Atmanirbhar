from flask import Flask, request, render_template
import reports1
import skillsmapplot
import skillsbarplot
import genderpieplot
import urllib3
import pandas as pd
import sqlalchemy
import matplotlib.pyplot as plt
from matplotlib import style
import matplotlib
import gc
#!pip install geopandas
#!pip install descartes


import geopandas as gpd
import descartes as dc
matplotlib.use('Agg')
urllib3.disable_warnings()


df=reports1.dbgetresult()

genderpieplot.genderpieplot(df)

skillsbarplot.skillsbarplot(df)

skillsmapplot.skillsmapplot(df)

#import collaborative_filtering
app = Flask(__name__)
urllib3.disable_warnings()


@app.route('/',methods=['POST','GET'])
def getrate1():

	#statelist
	statelist=reports1.statelist(df)
	skilllist=reports1.skilllist()
	#s1=request.form['statelist']
	#s0=request.form['skilllist']
	#t1=request.form['text1']
	#args = [s0,s1,t1]
	#q1=reports1.querycreate(args)
	#print(s1)
	return render_template('image2.html', statelist=statelist, skilllist=skilllist, url1='/static/images/genderpieplot.png', url2='/static/images/skillsbarplot.png',  url3='/static/images/skillsmapplot.png')


@app.route('/image1.html',methods=['POST','GET'])
def getrate():

	#statelist
	statelist=reports1.statelist(df)
	skilllist=reports1.skilllist()
	s1=request.form['statelist']
	s0=request.form['skilllist']
	t1=request.form['text1']
	#args = [s0,s1,t1]
	#print(type(args))
	q1=reports1.querycreate(s0,s1,t1)
	q1=pd.DataFrame(q1)
	q1.reset_index(drop=True,inplace=True)
	q1 = q1[['NAME', 'GENDER', 'UID', 'DISTRICT', 'CITY','STATE']]
	#q1.reindex(columns=column_names)
	r=q1.shape[0]
	s=request.form['skilllist']
	x=int(r)*600
	if q1.shape[0] == 0:
		print("Into Option 1")
		return render_template('image4.html', statelist=statelist, skilllist=skilllist, url1='/static/images/genderpieplot.png', url2='/static/images/skillsbarplot.png',  url3='/static/images/skillsmapplot.png',tables=[q1.to_html(index = False,classes='mystyle')],titles = ['na'])
	else:
		print("Into Option 2")
		return render_template('image1.html', statelist=statelist, skilllist=skilllist, url1='/static/images/genderpieplot.png', url2='/static/images/skillsbarplot.png',  url3='/static/images/skillsmapplot.png', url4=r, url5=s,url6=x,tables=[q1.to_html(index = False,classes='mystyle')],titles = ['na'])


@app.route('/image3.html',methods=['POST','GET'])
def getrate3():
	return render_template('image3.html')



if __name__ == '__main__':
	#app.debug = True
	app.run(debug=True,port=5055)
