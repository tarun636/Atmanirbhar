#!pip install geopandas
#!pip install descartes
import pandas as pd
import sqlalchemy
import numpy as np
import geopandas as gpd
import descartes as dc
import matplotlib.pyplot as plt
from matplotlib import style
import gc
import mysql.connector


def dbgetresult():
 engine = sqlalchemy.create_engine('mysql+pymysql://admin:AnMysql$1234@database-1.cvnuvrn7wcss.us-east-1.rds.amazonaws.com:3306/aatmanirbhar_db')
 df = pd.read_sql_query('SELECT * FROM persons2', engine)
 df = pd.concat([df.drop('skills', 1), df['skills'].str.get_dummies(sep=",")], 1)
 print("Database connected and Data Retrieved Successfully")
 return df


df = dbgetresult()



def statelist(df):
    statelist=df.lstate.unique()

    statelist= np.insert(statelist, 29, "Select a state", axis=0)
    print(statelist)
    return statelist

def skilllist():
    skilllist = ["Security", "Plumber", "Sweeper", "Electrician", "Mason"]
    skilllist= np.insert(skilllist, 5, "Select skill", axis=0)
    return skilllist

"""def querycreate(s0,s1,t1):
    t2=int(t1)
    state = s1
    skill= '%'+s0+'%'
    lim = t2
    conn=mysql.connector.connect(user='admin',password='AnMysql$1234',host='database-1.cvnuvrn7wcss.us-east-1.rds.amazonaws.com',database='aatmanirbhar_db')
    mycursor=conn.cursor( buffered=True, dictionary=True)
    print("Query Being Executed")
    mycursor.execute("SELECT name AS NAME,uid AS UID,gender AS GENDER,ldist AS DISTRICT,lcity AS CITY,lstate AS STATE FROM persons2 WHERE lstate=%s AND skills LIKE %s LIMIT %s",(state,skill,lim,))
    myresult = mycursor.fetchall()
    if myresult == None:
        print("There are no results for this query")
        column_names = ["NAME", "UID", "GENDER", "DISTRICT", "CITY", "STATE"]
        myresult = pd.DataFrame(columns = column_names)
    return myresult
    """

def querycreate(s0,s1,t1):
    t2=int(t1)
    state = s1
    skill= '%'+s0+'%'
    lim = t2
    conn=mysql.connector.connect(user='admin',password='AnMysql$1234',host='database-1.cvnuvrn7wcss.us-east-1.rds.amazonaws.com',database='aatmanirbhar_db')
    mycursor=conn.cursor( buffered=True, dictionary=True)
    print("Query Being Executed")
    mycursor.execute("SELECT name AS NAME,uid AS UID,gender AS GENDER,ldist AS DISTRICT,lcity AS CITY,lstate AS STATE FROM persons2 WHERE lstate=%s AND skills LIKE %s LIMIT %s",(state,skill,lim,))
    print("Retrieveing Result")
    print(mycursor.rowcount)
    myresult = mycursor.fetchall()
    if mycursor.rowcount == 0:
        print("There are no results for this query")
        column_names = ["NAME", "UID", "GENDER", "DISTRICT", "CITY", "STATE"]
        myresult = pd.DataFrame(columns = column_names)
    return myresult
