import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import style
import numpy as np
import gc

"""
def skillsbarplot(df_Updated):
    df_Carpenter=df_Updated.loc[df_Updated['Carpenter'] == 1]
    Carpenter_Value=df_Carpenter['Carpenter'].value_counts()
    df_Civil=df_Updated.loc[df_Updated['Civil'] == 1]
    Civil_Value=df_Civil['Civil'].value_counts()
    df_Electrician=df_Updated.loc[df_Updated['Electrician'] == 1]
    Electrician_Value=df_Electrician['Electrician'].value_counts()
    df_HomeMaid=df_Updated.loc[df_Updated['HomeMaid'] == 1]
    HomeMaid_Value=df_HomeMaid['HomeMaid'].value_counts()
    df_Plumber=df_Updated.loc[df_Updated['Plumber'] == 1]
    Plumber_Value=df_Plumber['Plumber'].value_counts()
    df_Security=df_Updated.loc[df_Updated['Security'] == 1]
    Security_Value=df_Security['Security'].value_counts()
    Skill_df = Carpenter_Value.append(Civil_Value).append(Electrician_Value).append(HomeMaid_Value).append(Plumber_Value).append(Security_Value)
    Skill_df.index = ['Carpenter','Civil','Electrician','HomeMaid','Plumber','Security']
    Skill_df = Skill_df.to_frame()
    #plt.bar(y_pos, heights)
    # Rotation of the bars names
    #lt.xticks(y_pos, bars, rotation=90)
    plot1 = Skill_df.plot(kind='bar',rot=45)
    plot1.figure.savefig('static/images/plotskill.png')
    lst = [df_Carpenter, df_Civil, df_Electrician, df_HomeMaid, df_Plumber,df_Security]
    del lst
    lst1 = [Carpenter_Value, Civil_Value, Electrician_Value, HomeMaid_Value, Plumber_Value,Security_Value]
    del lst1
    del plot1
    gc.collect()
"""

def skillsbarplot(df_Updated):
    df_Mason=df_Updated.loc[df_Updated['Mason'] == 1]
    Mason_Value=df_Mason['Mason'].value_counts()
    df_Electrician=df_Updated.loc[df_Updated['Electrician'] == 1]
    Electrician_Value=df_Electrician['Electrician'].value_counts()
    df_Sweeper=df_Updated.loc[df_Updated['Sweeper'] == 1]
    Sweeper_Value=df_Sweeper['Sweeper'].value_counts()
    df_Plumber=df_Updated.loc[df_Updated['Plumber'] == 1]
    Plumber_Value=df_Plumber['Plumber'].value_counts()
    df_Security=df_Updated.loc[df_Updated['Security'] == 1]
    Security_Value=df_Security['Security'].value_counts()
    Skill_df = Mason_Value.append(Electrician_Value).append(Sweeper_Value).append(Plumber_Value).append(Security_Value)
    Skill_df.index = ['Mason','Electrician','Sweeper','Plumber','Security']
    #modified
    Skill_df = Skill_df.to_frame()
    Skill_df.rename(columns = {0:'Workforce'}, inplace = True)
    Skill_df['Skill'] = Skill_df.index
    y_pos = np.arange(len(Skill_df.Workforce))
    x_labels = ['Dummy','Mason','Electrician','Sweeper','Plumber','Security']
    fig, ax = plt.subplots(1,figsize=(7, 7))
    barplot = ax.bar(y_pos, Skill_df.Workforce,width=0.5,color=['#CCDBFF','#99B8FF','#6694FF','#004DFF','#003ABF'])
    ax.set_xticklabels(['','Mason','Electrician','Sweeper','Plumber','Security',''])
    #ax.set_title('State Wise Resource Distribution',fontsize=20,fontweight=4,pad=40)
    plt.xticks(rotation=45,fontsize='x-small',fontweight ='light')
    plt.yticks(fontsize='medium',fontweight ='regular')
    #plt.rcParams.update({'font.size': 25})
    #plt.rcParams['axes.labelsize'] = 'small'
    plt.savefig('static/images/skillsbarplot.png', dpi=300, bbox_inches='tight', pad_inches=0.5, frameon=True, transparent=True)
    plt.show()
    lst = [df_Mason, df_Electrician, df_Sweeper, df_Plumber,df_Security]
    del lst
    lst1 = [Mason_Value, Electrician_Value, Sweeper_Value, Plumber_Value,Security_Value]
    del lst1
    gc.collect()
