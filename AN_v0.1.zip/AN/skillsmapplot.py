import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib import style
import gc

"""
def skillsmapplot(df):
 fp = "Indian_States.dbf"
 map_df = gpd.read_file(fp)
 df_state = df['lstate'].value_counts().to_frame()
 df_state.index.name='State_Name'
 map_df['st_nm']=map_df['st_nm'].str.replace(" ","")
 merged = map_df.set_index('st_nm').join(df_state)
 merged['lstate']=merged['lstate'].fillna(0)
 fig, ax = plt.subplots(1, figsize=(20, 8))
 ax.axis('off')
 ax.set_title('State Wise Resource Distribution', fontdict={'fontsize': '25', 'fontweight' : '3'})
 plot2 = merged.plot(column='lstate', cmap='YlOrRd', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
 plot2.figure.savefig('static/images/plotgender14.png')
 lst = [map_df, df_state, merged]
 del lst
 del plot2
 gc.collect()
"""

def skillsmapplot(df):
    fp = "Indian_States.dbf"
    map_df = gpd.read_file(fp)
    df_state = df['lstate'].value_counts().to_frame()
    df_state.index.name='State_Name'
    map_df['st_nm']=map_df['st_nm'].str.replace(" ","")
    merged = map_df.set_index('st_nm').join(df_state)
    merged['lstate']=merged['lstate'].fillna(0)
    #modified
    fig, ax = plt.subplots(1, figsize=(7, 7))
    ax.axis('off')
    #ax.set_title('State Wise Resource Distribution', fontdict={'fontsize': '20', 'fontweight' : '4'},pad=40)
    plot = merged.plot(column='lstate', cmap='YlGn', linewidth=0.8, ax=ax, edgecolor='1.8', legend=True)
    plt.savefig('static/images/skillsmapplot.png', dpi=300, bbox_inches='tight', pad_inches=0.5, frameon=True, transparent=True)
    lst = [map_df, df_state, merged]
    del lst
    del plot
    gc.collect()
