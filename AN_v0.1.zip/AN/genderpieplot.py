import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import style
import gc

"""
def genderpieplot(df):
 df_gender = df['gender'].value_counts().to_frame()
 df_gender.index = ['Male', 'Female']
 explode = [0, 0.10]
 plot3 = df_gender.plot.pie(y='gender',figsize=(6, 6),explode=explode)
 plot3.figure.savefig('static/images/plotgender12.png')
 del plot3
 gc.collect()
"""

def genderpieplot(df):
    df_gender = df['gender'].value_counts().to_frame()
    df_gender.index = ['Male', 'Female']
    explode = [0, 0.10]
    plot = df_gender.plot.pie(y='gender',figsize=(7, 7),autopct = "%.2f%%", colors = ['#e37430', '#e31414'],explode=explode, fontsize=12)
    plt.rcParams.update({'font.size': 25})
    plt.ylabel("Gender Dirstribution", fontsize=12)
    #plt.title('Gender Wise Resource Distribution', fontdict={'fontsize': '20', 'fontweight' : '4'},pad=40)
    plt.savefig('static/images/genderpieplot.png', dpi=300, bbox_inches='tight', pad_inches=0.1, frameon=True, transparent=True)
    del plot
    gc.collect()
